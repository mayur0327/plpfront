import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CouponComponent } from './coupon/coupon.component';
import { SentComponent } from './sent/sent.component';

const routes: Routes = [
  {path: '', redirectTo : '/home', pathMatch: 'full'},
  {path: '/home', component: HomeComponent},
  {path: '/coupon', component : CouponComponent},
  {path: '/sent', component : SentComponent},
  {path : '**', redirectTo : '/home', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes), CommonModule],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
